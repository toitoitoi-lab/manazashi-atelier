// カメラの読み取りを作り物の顔で動かして、目の動き・帯・まばたきで順番に選ぶ を確かめる
const {chromium}=require('playwright');
const URL='file:///home/claude/manazashi/index.html';
const results=[]; const ok=(n,c,i='')=>results.push((c?'OK  ':'NG  ')+n+(i?'  '+i:''));
const FAKE=()=>{
  window.__mzGaze={x:.5,y:.5}; window.__mzBlink=0;
  window.__mzTestCam=()=>{
    let g=window.__mzGaze; const dot=document.getElementById('calibDot'), cal=document.getElementById('calib');
    if(cal&&!cal.hidden&&dot&&!dot.hidden&&dot.style.left){ g={x:parseFloat(dot.style.left)/100,y:parseFloat(dot.style.top)/100}; }
    const L=[...Array(478)].map(()=>({x:.5,y:.5}));
    L[33]={x:.40,y:.45};L[133]={x:.46,y:.45};L[362]={x:.54,y:.45};L[263]={x:.60,y:.45};L[1]={x:.5-(g.x-.5)*.04,y:.55+(g.y-.5)*.03};
    const n=()=> (Math.random()-.5)*.0004;
    const ix=(g.x-.5)*.012+n(), iy=(g.y-.5)*.006+n();
    L[468]={x:.43+ix,y:.45+iy};L[473]={x:.57+ix,y:.45+iy};L[159]={x:.43,y:.44};L[145]={x:.43,y:.46};L[386]={x:.57,y:.44};L[374]={x:.57,y:.46};
    const yaw=(g.x-.5)*.6, pit=(g.y-.5)*.4;
    const data=[1,0,Math.sin(yaw),0, 0,1,Math.sin(pit),0, Math.sin(yaw),Math.sin(pit),1,0, 0,0,0,1];
    const b=window.__mzBlink;
    return {faceLandmarks:[L],faceBlendshapes:[{categories:[{categoryName:'eyeBlinkLeft',score:b},{categoryName:'eyeBlinkRight',score:b}]}],facialTransformationMatrixes:[{data}]};
  };
};
(async()=>{
 for(const [input,extra] of [['gaze',{}],['head',{}],['gaze',{gridOpen:'grid',gridKeep:{c:2,r:2}}]]){ const tag=input+(extra.gridOpen?'（分け方 横2×縦2）':'');
  const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1280,height:800}}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.addInitScript(FAKE);
  await p.addInitScript(s=>{localStorage.setItem('manazashi-atelier',JSON.stringify(s));},Object.assign({input,select:'scan',pos:'top',mig1161:true,mig1162:true,smooth:4},extra));
  await p.goto(URL); await p.waitForTimeout(600);
  // 調整（9点）
  await p.evaluate(()=>{document.getElementById('gear').click();}); await p.waitForTimeout(200);
  await p.evaluate(()=>document.getElementById('bCalib').click());
  await p.waitForFunction(()=>!window.__mzState().calib.active,null,{timeout:40000});
  await p.waitForTimeout(1500);
  ok(`${tag}：調整できた`,await p.evaluate(()=>window.__mzState().model));
  await p.evaluate(()=>document.getElementById('startBtn').click()); await p.waitForTimeout(500);
  const S=()=>p.evaluate(()=>window.__mzState());
  // 画面の中のいろいろな所へ（ふちではなく中まで届くか）
  const targets=[[.5,.55],[.3,.5],[.7,.6],[.45,.75],[.6,.4]]; let maxErr=0, edgeStuck=0;
  for(const [x,y] of targets){ await p.evaluate(([x,y])=>{window.__mzGaze={x,y};},[x,y]); await p.waitForTimeout(1500);
    const s=await S(); const ex=Math.abs(s.sm.x/s.W-x), ey=Math.abs(s.sm.y/s.H-y); maxErr=Math.max(maxErr,ex,ey);
    if(s.sm.x<5||s.sm.x>s.W-5||s.sm.y<5||s.sm.y>s.H-5) edgeStuck++; }
  if(!extra.gridOpen) ok(`${tag}：画面の中まで輪が届く（ふちに張りつかない）`,edgeStuck===0&&maxErr<.12,`ずれ最大 ${(maxErr*100).toFixed(1)}%`);
  else ok(`${tag}：輪がマスのまんなかに移る（ふちに張りつかない）`,edgeStuck===0);
  // 分け方（横2×縦2）でも帯に入れる
  await p.evaluate(()=>{const s=JSON.parse(localStorage.getItem('manazashi-atelier'));});
  await p.evaluate(()=>{window.__mzGaze={x:.5,y:.04};}); await p.waitForTimeout(1500);
  let s=await S(); ok(`${tag}：上のボタンの帯に入れる`,s.band&&s.ui.y<=s.band.y1,`ui.y=${Math.round(s.ui.y)} 帯=${s.band&&Math.round(s.band.y1)}`);
  // まばたき：帯に入ったので選ぶのが始まっているはず → 少し長め＝次へ
  const st0=(await S()).scan; ok(`${tag}：帯に目を入れると選ぶのが始まる`,st0.on&&st0.ctx==='tb',JSON.stringify(st0));
  await p.evaluate(()=>{window.__mzBlink=.9;}); await p.waitForTimeout(550); await p.evaluate(()=>{window.__mzBlink=0;}); await p.waitForTimeout(300);
  const st1=(await S()).scan; ok(`${tag}：少し長めのまばたきで次へ`,st1.on&&st1.idx===st0.idx+1,`${st0.idx}→${st1.idx}`);
  // ふつうのまばたき（0.15秒）では動かない
  await p.evaluate(()=>{window.__mzBlink=.9;}); await p.waitForTimeout(150); await p.evaluate(()=>{window.__mzBlink=0;}); await p.waitForTimeout(300);
  const st2=(await S()).scan; ok(`${tag}：ふつうのまばたきでは動かない`,st2.idx===st1.idx,`${st1.idx}→${st2.idx}`);
  // 最初のボタン（いろ）まで戻して、長くとじて決定 → 一覧が開く
  await p.evaluate(()=>{window.__mzGaze={x:.5,y:.6};}); await p.waitForTimeout(1200);
  await p.evaluate(()=>{window.__mzBlink=.9;}); await p.waitForTimeout(1300); await p.evaluate(()=>{window.__mzBlink=0;}); await p.waitForTimeout(400);
  const st3=(await S()).scan; ok(`${tag}：絵の上で長くとじると、ボタン選びが始まる`,st3.on&&st3.ctx==='tb',JSON.stringify(st3));
  await p.evaluate(()=>{window.__mzBlink=.9;}); await p.waitForTimeout(1300); await p.evaluate(()=>{window.__mzBlink=0;}); await p.waitForTimeout(500);
  ok(`${tag}：長くとじて決定（いろの一覧が開く）`,await p.$eval('#picker',e=>!e.hidden));
  ok(`${tag}：エラーなし`,errs.length===0,errs.join());
  await b.close(); }
 console.log(results.join('\n')); const ng=results.filter(r=>r.startsWith('NG')).length; console.log(ng?`\n${ng} 件 NG`:'\nすべて OK');
})();
