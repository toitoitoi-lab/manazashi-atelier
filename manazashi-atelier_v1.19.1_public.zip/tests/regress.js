// まなざしアトリエ：版を上げるたびに必ず通す確認（一度直した操作が戻っていないか）
const {chromium}=require('playwright');
const URL='file:///home/claude/manazashi/index.html';
const results=[]; const ok=(name,cond,info='')=>results.push((cond?'OK  ':'NG  ')+name+(info?'  '+info:''));
(async()=>{const b=await chromium.launch();
 const page=async(st,vp={width:1280,height:800})=>{const bb=await chromium.launch();const p=await bb.newPage({viewport:vp});const oc=p.close.bind(p);p.close=async()=>{await oc();await bb.close();};p._errs=[];p.on('pageerror',e=>p._errs.push(e.message));
   await p.addInitScript(s=>{if(!sessionStorage.getItem('r')){sessionStorage.setItem('r',1);localStorage.setItem('manazashi-atelier',JSON.stringify(Object.assign({mig1161:true,mig1162:true},s)));}},st);
   await p.goto(URL);await p.bringToFront();await p.waitForTimeout(500);return p;};
 const cursorAt=(p,sel)=>p.evaluate(s=>{const e=document.querySelector(s);return getComputedStyle(e).cursor;},sel);
 // 0) 画面が動いている（描く・輪・ボタンの動きを毎回まわす仕組みが止まっていない）
 for(const input of ['hand','gaze']){ const p=await page({input});
   const alive=await p.evaluate(async()=>{document.body.classList.remove('pre');await new Promise(r=>setTimeout(r,300));return document.body.classList.contains('pre');});
   ok(`画面の動きが止まっていない（${input}）`,alive); ok(`エラーなし（読み込み ${input}）`,p._errs.length===0,p._errs.join()); await p.close(); }
 // 1) マウスの矢印：どの入力でも、ボタン・歯車・一覧の上では消えない／マウスとカメラでは絵の上でも消えない
 for(const input of ['hand','pointer','ipad','gaze','head']){
   const p=await page({input}); await p.click('#startBtn'); await p.waitForFunction(()=>!document.body.classList.contains('pre')||!document.getElementById('picker').hidden,null,{timeout:8000}); await p.waitForTimeout(200);
   const tb=await cursorAt(p,'#tbColor'), gear=await cursorAt(p,'#gear'), art=await cursorAt(p,'#art');
   ok(`矢印（${input}）：ボタンの上で見える`,tb!=='none',tb); ok(`矢印（${input}）：歯車の上で見える`,gear!=='none',gear);
   if(input==='hand'||input==='gaze'||input==='head') ok(`矢印（${input}）：絵の上で見える`,art!=='none',art);
   await p.evaluate(()=>document.getElementById('tbColor').click()); await p.waitForTimeout(250);
   ok(`矢印（${input}）：一覧の上で見える`,(await cursorAt(p,'#pkGrid .dw'))!=='none');
   ok(`エラーなし（${input}）`,p._errs.length===0,p._errs.join()); await p.close(); }
 // 2) カメラの入力のままでも、マウスで入り口に入れる（見つめるだけ）
 { const p=await page({input:'gaze'}); const r=await p.$eval('#startBtn',e=>{const q=e.getBoundingClientRect();return {x:q.left+q.width/2,y:q.top+q.height/2}});
   await p.mouse.move(r.x-200,r.y); for(let i=0;i<14;i++){await p.mouse.move(r.x+(i%2),r.y);await p.waitForTimeout(250);}
   ok('カメラのままマウスで「えを かく」に入れる',await p.$eval('#welcome',e=>e.hidden)); await p.close(); }
 // 3) 帯の左はしにマウスを置いても、一番近いボタンが選ばれ、輪がボタンに重なる
 { const p=await page({input:'hand'}); await p.click('#startBtn'); await p.waitForFunction(()=>!document.body.classList.contains('pre')||!document.getElementById('picker').hidden,null,{timeout:8000}); await p.waitForTimeout(200);
   const y=await p.$eval('#tbBrush',e=>{const r=e.getBoundingClientRect();return r.top+r.height/2});
   for(let i=0;i<8;i++){await p.mouse.move(3,y+i);await p.waitForTimeout(100);}
   const hot=await p.evaluate(()=>[...document.querySelectorAll('#toolbar .dw.hot')].map(e=>e.id)); ok('帯の左はしでもボタンが選ばれる',hot.length===1,hot.join()); await p.close(); }
 // 4) 一覧はどの画面でも2行（4つ以下は1行、スマホは3行まで）、横に長い1行・縦に長い2列にならない
 for(const vp of [{width:1440,height:900},{width:1280,height:800},{width:820,height:1180},{width:1180,height:820}]){
   const p=await page({input:'hand'},vp); await p.click('#startBtn'); await p.waitForFunction(()=>!document.body.classList.contains('pre')||!document.getElementById('picker').hidden,null,{timeout:8000}); await p.waitForTimeout(200);
   for(const id of ['#tbSym','#tbColor','#tbBrush']){ await p.evaluate(i=>document.querySelector(i).click(),id); await p.waitForTimeout(250);
     const rows=await p.evaluate(()=>new Set([...document.querySelectorAll('#pkGrid .dw')].map(e=>e.offsetTop)).size);
     ok(`一覧2行（${vp.width}×${vp.height} ${id}）`,rows===2,rows+'行'); await p.evaluate(()=>document.querySelector('#pkGrid .close').click()); await p.waitForTimeout(250);} await p.close(); }
 // 5) ボタンの列（上下に置いたとき）は、1行に収まるなら1行。帯が画面の高さの4分の1をこえない（絵の紙をせまくしない）
 for(const vp of [{width:1180,height:820},{width:820,height:1180},{width:1280,height:800},{width:1024,height:768}]){
   for(const pos of ['top','bottom']){ const p=await page({input:'gaze',pos},vp); await p.click('#startBtn'); await p.waitForFunction(()=>!document.body.classList.contains('pre')||!document.getElementById('picker').hidden,null,{timeout:8000}); await p.waitForTimeout(250);
     const r=await p.evaluate(()=>{const ys=new Set([...document.querySelectorAll('#toolbar .dw')].filter(e=>!e.hidden).map(e=>e.offsetTop));const b=document.getElementById('tbBand').getBoundingClientRect();return {rows:ys.size,band:Math.round(b.height),H:innerHeight};});
     ok(`ボタンの列（${pos} ${vp.width}×${vp.height}）：${r.rows}行・帯${r.band}px`,r.rows===1&&r.band<=r.H/4); await p.close(); } }
 // 6) 版の表示が入り口と設定のいちばん上に出る
 { const p=await page({input:'hand'}); const v=await p.$$eval('.verText',es=>es.map(e=>e.textContent)); ok('版の表示（入り口・設定の上）',v.length>=2&&v.every(t=>/v\d+\.\d+\.\d+ public/.test(t)),v[0]); await p.close(); }

 // 7) のこす → つづきから で同じ絵が戻る（6つまで）、ボタンの列に「のこす」がある
 { const p=await page({input:'hand',penDown:'none'}); await p.click('#startBtn'); await p.waitForFunction(()=>!document.body.classList.contains('pre')||!document.getElementById('picker').hidden,null,{timeout:8000}); await p.waitForTimeout(300);
   ok('ボタンの列に「のこす」',await p.$eval('#tbKeep',e=>!e.hidden));
   await p.mouse.move(700,400); for(let i=0;i<40;i++){await p.mouse.move(700+i*8,400+Math.sin(i/4)*60);await p.waitForTimeout(16);}
   await p.mouse.move(700,100);
   const sig=()=>p.evaluate(()=>{const c=document.getElementById('art'),x=c.getContext('2d');let s=0;const d=x.getImageData(0,0,c.width,c.height).data;for(let i=0;i<d.length;i+=4097)s+=d[i]+d[i+1]+d[i+2];return s;});
   const before=await sig();
   await p.evaluate(()=>document.getElementById('tbKeep').click()); await p.waitForFunction(()=>document.getElementById('bigToast').textContent.includes('のこしたよ'),null,{timeout:8000}); await p.waitForTimeout(300);
   await p.reload(); await p.waitForTimeout(600);
   await p.click('#startBtn'); await p.waitForFunction(()=>!document.body.classList.contains('pre')||!document.getElementById('picker').hidden,null,{timeout:8000}); await p.waitForTimeout(400);
   const pk=await p.$eval('#picker',e=>!e.hidden); ok('「えを かく」で「あたらしく／つづきから」が出る',pk);
   await p.click('#pkGrid .dw[data-val="cont"]'); await p.waitForTimeout(400);
   const n=await p.$$eval('#pkGrid .dw[data-kind="resume"]',es=>es.length); ok('つづきの一覧に残した絵が出る',n>=1,n+'こ');
   await p.click('#pkGrid .dw[data-kind="resume"]'); await p.waitForTimeout(800);
   const after=await sig(); ok('つづきから開くと同じ絵が戻る',Math.abs(after-before)/Math.max(1,before)<0.02,before+' / '+after);
   ok('エラーなし（セーブ）',p._errs.length===0,p._errs.join()); await p.close(); }
 // 8) ウィンドウの大きさを変えても、縦横比が変わらない（円が楕円にならない）
 { const p=await page({input:'hand',penDown:'none',pos:'off'}); await p.click('#startBtn'); await p.waitForFunction(()=>!document.body.classList.contains('pre')||!document.getElementById('picker').hidden,null,{timeout:8000}); await p.waitForTimeout(300);
   await p.evaluate(()=>{const c=document.getElementById('art'),x=c.getContext('2d');x.save();x.setTransform(1,0,0,1,0,0);x.fillStyle='#ff0000';x.beginPath();x.arc(c.width/2,c.height/2,100,0,7);x.fill();x.restore();});
   await p.setViewportSize({width:1600,height:800}); await p.waitForTimeout(700);
   const r=await p.evaluate(()=>{const c=document.getElementById('art'),x=c.getContext('2d'),d=x.getImageData(0,0,c.width,c.height).data;let minx=1e9,maxx=-1,miny=1e9,maxy=-1;for(let y=0;y<c.height;y+=2)for(let X=0;X<c.width;X+=2){const i=(y*c.width+X)*4;if(d[i]>200&&d[i+1]<60&&d[i+2]<60){if(X<minx)minx=X;if(X>maxx)maxx=X;if(y<miny)miny=y;if(y>maxy)maxy=y;}}return {w:maxx-minx,h:maxy-miny};});
   ok('大きさを変えても円が円のまま',r.h>0&&Math.abs(r.w/r.h-1)<0.06,JSON.stringify(r)); await p.close(); }
 // 9) 設定を開いている間・閉じた直後は描かない（合図なしでも）
 { const p=await page({input:'hand',penDown:'none',pos:'left'}); await p.click('#startBtn'); await p.waitForFunction(()=>!document.body.classList.contains('pre'),null,{timeout:8000});
   const sig=()=>p.evaluate(()=>{const c=document.getElementById('art'),x=c.getContext('2d');let s=0;const d=x.getImageData(0,0,c.width,c.height).data;for(let i=0;i<d.length;i+=997)s+=d[i]+d[i+1]+d[i+2];return s;});
   await p.mouse.move(900,700); await p.waitForTimeout(900); const s0=await sig();
   await p.click('#gear'); await p.waitForTimeout(200);
   for(let i=0;i<40;i++){await p.mouse.move(350+i*8,300+Math.sin(i/4)*100);await p.waitForTimeout(16);}
   const s1=await sig(); ok('設定を開いている間は描かない',s1===s0);
   await p.click('#closePanel'); for(let i=0;i<10;i++){await p.mouse.move(400+i*10,400);await p.waitForTimeout(30);}
   const s2=await sig(); ok('設定を閉じた直後は描かない',s2===s0);
   ok('エラーなし（設定中）',p._errs.length===0,p._errs.join()); await p.close(); }
 await b.close(); console.log(results.join('\n')); const ng=results.filter(r=>r.startsWith('NG')).length; console.log(ng?`\n${ng} 件 NG`:'\nすべて OK');
})();
