// あそぶ（みつけて・ついてきて・ふうせん）と、設定の「ひとつ前にもどす／はじめにもどす」を、マウスで確かめる
const {chromium}=require('playwright');
const URL='file:///home/claude/manazashi/index.html';
const results=[]; const ok=(n,c,i='')=>results.push((c?'OK  ':'NG  ')+n+(i?'  '+i:''));
(async()=>{
  const b=await chromium.launch(); const p=await b.newPage({viewport:{width:1280,height:800}}); const errs=[]; p.on('pageerror',e=>errs.push(e.message));
  await p.addInitScript(()=>{window.__mzTest=true;});
  await p.addInitScript(s=>{localStorage.setItem('manazashi-atelier',JSON.stringify(s));},{input:'pointer',mig1161:true,mig1162:true,mig1190:true,gameGrid:{c:2,r:2},gameDwell:.5,gameLen:3,balloonN:2,followSec:6,sfx:false});
  await p.goto(URL); await p.waitForTimeout(600);
  const S=()=>p.evaluate(()=>window.__mzState());
  const sig=()=>p.evaluate(()=>{const c=document.getElementById('art'),x=c.getContext('2d');let s=0;const d=x.getImageData(0,0,c.width,c.height).data;for(let i=0;i<d.length;i+=997)s+=d[i]+d[i+1]+d[i+2];return s;});
  const area=()=>p.evaluate(()=>{const r=document.getElementById('art').getBoundingClientRect();return {x0:r.left,y0:r.top,x1:r.right,y1:r.bottom};});
  const choose=async id=>{ await p.click('#playBtn'); await p.waitForTimeout(300); const n=await p.$$eval('#pkGrid [data-kind="games"]',e=>e.length); await p.click(`#pkGrid [data-kind="games"][data-val="${id}"]`); await p.waitForTimeout(400); return n; };
  const backHome=async()=>{ await p.click('#gameEnd2'); await p.waitForTimeout(400); };

  // ③ ふうせん
  const n=await choose('balloon'); ok('「あそぶ」で3つのあそびから選べる',n===3,n+'こ');
  let s=await S(); ok('ふうせんが始まる',s.game.on&&s.game.mode==='balloon');
  await p.waitForTimeout(1800); s=await S(); ok('ふうせんが同時に2こ出る',s.game.balloons.length===2,s.game.balloons.length+'こ');
  const sg0=await sig();
  for(let k=0;k<12;k++){ s=await S(); if(s.game.phase==='done'||!(await p.$eval('#gameDone',e=>e.hidden))) break; const bl=s.game.balloons[0]; if(!bl){ await p.waitForTimeout(400); continue; }
    const A=s.A; await p.mouse.move(A.x0+(bl.cx+.5)*(A.x1-A.x0)/2+3,A.y0+(bl.cy+.5)*(A.y1-A.y0)/2+3,{steps:4}); await p.waitForTimeout(1100); }
  await p.waitForTimeout(1500);
  ok('ふうせんを3こわると「できた」が出る',!(await p.$eval('#gameDone',e=>e.hidden)),await p.$eval('#gdText',e=>e.textContent));
  ok('われた所に紙ふぶきがのこる',(await sig())!==sg0);
  await backHome();
  ok('おわると入り口にもどる',!(await p.$eval('#welcome',e=>e.hidden)));

  // ② ついてきて
  await choose('follow'); s=await S(); ok('ついてきてが始まる',s.game.on&&s.game.mode==='follow');
  const sf0=await sig(); const t0=Date.now();
  while(Date.now()-t0<8000){ s=await S(); if(!(await p.$eval('#gameDone',e=>e.hidden))) break; if(s.game.f) await p.mouse.move(s.game.f.x,s.game.f.y); await p.waitForTimeout(60); }
  await p.waitForTimeout(1200);
  ok('ついてきて：時間がたつと「できた」が出る',!(await p.$eval('#gameDone',e=>e.hidden)),await p.$eval('#gdText',e=>e.textContent));
  const ft=await p.$eval('#gdText',e=>e.textContent); ok('追いかけた時間が数えられる',/([3-9]|\d\d)びょう/.test(ft),ft);
  ok('通った所に色の道がのこる',(await sig())!==sf0);
  await backHome();
  // 目がはなれたら止まって待つ
  await choose('follow'); await p.mouse.move(5,790); await p.waitForTimeout(3500); const a1=(await S()).game.f; await p.waitForTimeout(800); const a2=(await S()).game.f;
  ok('ついてきて：目がはなれると止まって待つ',Math.hypot(a1.x-a2.x,a1.y-a2.y)<1,JSON.stringify([a1,a2]));
  await p.mouse.move(a2.x,a2.y); await p.waitForTimeout(900); const a3=(await S()).game.f;
  ok('ついてきて：目がもどると、また動く',Math.hypot(a3.x-a2.x,a3.y-a2.y)>2);
  await p.click('#gameEnd'); await p.waitForTimeout(400);

  // ① みつけて
  await choose('find'); await p.waitForTimeout(1500);
  for(let k=0;k<10;k++){ s=await S(); if(!(await p.$eval('#gameDone',e=>e.hidden))) break; const t=s.game.t; if(!t){ await p.waitForTimeout(400); continue; }
    const A=s.A; await p.mouse.move(A.x0+(t.cx+.5)*(A.x1-A.x0)/2+3,A.y0+(t.cy+.5)*(A.y1-A.y0)/2+3,{steps:4}); await p.waitForTimeout(1100); }
  await p.waitForTimeout(1500);
  ok('みつけて：3こ見つけると「できた」',/3こ みつけた/.test(await p.$eval('#gdText',e=>e.textContent)));
  await p.click('#gameAgain'); await p.waitForTimeout(400); s=await S(); ok('「もういちど」で同じあそび',s.game.on&&s.game.mode==='find');
  await p.click('#gameEnd'); await p.waitForTimeout(400);

  // 設定のもどす
  const LS=()=>p.evaluate(()=>JSON.parse(localStorage.getItem('manazashi-atelier')));
  await p.click('#gear'); await p.waitForTimeout(200);
  await p.evaluate(()=>{const r=document.getElementById('rSize'); r.value='60'; r.dispatchEvent(new Event('input'));}); await p.waitForTimeout(1700);
  await p.evaluate(()=>{const r=document.getElementById('rDwell'); r.value='2.5'; r.dispatchEvent(new Event('input'));}); await p.waitForTimeout(300);
  let L=await LS(); ok('設定を変えた',L.size===60&&L.dwell===2.5);
  await p.click('#bSetUndo'); await p.waitForTimeout(200); L=await LS(); ok('「ひとつ前の設定にもどす」で1つだけもどる',L.size===60&&L.dwell!==2.5,`size ${L.size} dwell ${L.dwell}`);
  await p.click('#bSetUndo'); await p.waitForTimeout(200); L=await LS(); ok('もう一度押すと、さらに前へ',L.size!==60,`size ${L.size}`);
  await p.evaluate(()=>{const r=document.getElementById('rSize'); r.value='70'; r.dispatchEvent(new Event('input'));}); await p.waitForTimeout(300);
  await p.click('#bSetReset'); await p.waitForTimeout(200); L=await LS(); ok('「はじめの設定にもどす」は1回目では変わらない（確かめ）',L.size===70);
  await p.click('#bSetReset'); await p.waitForTimeout(200); L=await LS(); ok('2回目で、はじめの設定にもどる',L.size===30&&L.mig1190===true,`size ${L.size}`);
  await p.click('#bSetUndo'); await p.waitForTimeout(200); L=await LS(); ok('はじめにもどしたあとも、ひとつ前にもどせる',L.size===70,`size ${L.size}`);
  ok('エラーなし',errs.length===0,errs.join());
  await b.close();
  console.log(results.join('\n')); const ng=results.filter(r=>r.startsWith('NG')).length; console.log(ng?`\n${ng} 件 NG`:'\nすべて OK');
})();
