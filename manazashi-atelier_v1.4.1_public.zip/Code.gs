/**
 * まなざしアトリエ v1.4.1 — 学校版（Google Apps Script）
 * index.html を表示し、「記録に追加」された作品を
 *   ・スプレッドシート（記録の表）
 *   ・ドライブのフォルダ（作品の画像 PNG）
 * に保存します。
 * 初回だけ、エディタで setup を実行してください（保存先が自動で作られます）。
 */

const APP_NAME = 'まなざしアトリエ';
const VERSION = '1.4.1';
const SHEET_NAME = '記録';
const HEADER = ['日時', '名前（記号）', '入力方法', 'ふで', 'いろ', 'もよう',
  '描いていた時間（秒）', '見た範囲（%）', '左上', '上', '右上', '左', '中央', '右', '左下', '下', '右下',
  '作品の画像', '記録した人', 'バージョン'];

function doGet() {
  return HtmlService.createHtmlOutputFromFile('index')
    .setTitle(APP_NAME)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, viewport-fit=cover')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/** 初回に一度だけエディタから実行：保存先のフォルダとスプレッドシートを作る */
function setup() {
  const folder = getFolder_();
  const sheet = getSheet_();
  Logger.log('作品フォルダ: ' + folder.getUrl());
  Logger.log('記録スプレッドシート: ' + sheet.getParent().getUrl());
}

/** アプリから呼ばれる：学校版であることと、スプレッドシートの場所を返す */
function getConfig() {
  return { mode: 'gas', version: VERSION, sheetUrl: getSheet_().getParent().getUrl() };
}

/** アプリから呼ばれる：作品1枚を記録する */
function saveRecord(r) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const base64 = String(r.image || '').split(',')[1];
    if (!base64) throw new Error('画像がありません');
    const blob = Utilities.newBlob(Utilities.base64Decode(base64), 'image/png', safeName_(r.fileName || 'manazashi.png'));
    const file = getFolder_().createFile(blob);

    const grid = (r.grid9 || []).slice(0, 9);
    while (grid.length < 9) grid.push('');
    let who = '';
    try { who = Session.getActiveUser().getEmail(); } catch (e) {}

    const sh = getSheet_();
    sh.appendRow([
      r.date ? new Date(r.date) : new Date(),
      String(r.name || ''), String(r.input || ''), String(r.brush || ''), String(r.color || ''), String(r.sym || ''),
      Number(r.seconds) || 0, Number(r.cover) || 0
    ].concat(grid).concat(['', who, VERSION]));
    const row = sh.getLastRow();
    sh.getRange(row, HEADER.indexOf('作品の画像') + 1)
      .setRichTextValue(SpreadsheetApp.newRichTextValue().setText(file.getName()).setLinkUrl(file.getUrl()).build());
    return { ok: true, fileUrl: file.getUrl(), row: row };
  } finally {
    lock.releaseLock();
  }
}

/* ---------- 内部で使う関数 ---------- */

function getFolder_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('FOLDER_ID');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) {} }
  const folder = DriveApp.createFolder(APP_NAME + '_作品');
  props.setProperty('FOLDER_ID', folder.getId());
  return folder;
}

function getSheet_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('SHEET_ID');
  let ss = null;
  if (id) { try { ss = SpreadsheetApp.openById(id); } catch (e) {} }
  if (!ss) {
    ss = SpreadsheetApp.create(APP_NAME + '_記録');
    props.setProperty('SHEET_ID', ss.getId());
    try { DriveApp.getFileById(ss.getId()).moveTo(getFolder_()); } catch (e) {}
  }
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.getSheets()[0];
    sh.setName(SHEET_NAME);
  }
  if (sh.getLastRow() === 0) {
    sh.appendRow(HEADER);
    sh.getRange(1, 1, 1, HEADER.length).setFontWeight('bold').setBackground('#e8e4fb');
    sh.setFrozenRows(1);
    sh.getRange('A:A').setNumberFormat('yyyy/mm/dd hh:mm');
  }
  return sh;
}

function safeName_(name) {
  return String(name).replace(/[\\/:*?"<>|]/g, '_').slice(0, 120);
}
